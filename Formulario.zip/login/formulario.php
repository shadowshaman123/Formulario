<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Obtener los valores enviados desde el formulario
  $carrera = $_POST['carreras'];
  $escogio = $_POST['escogio'];
  $sede = $_POST['sede'];
  $nombre = $_POST['nombre'];
  $apellidos = $_POST['apellidos'];
  $telefono = $_POST['telefono'];
  $correo = $_POST['correo'];

  //contenido del correo
  $to = 'gbarboza.es@gmail.com';  // Coloca aquí tu dirección de correo
  $subject = 'Nuevo registro en el formulario';
  $message = "Carrera: " . $carrera . "\n";
  $message .= "Escogió: " . $escogio . "\n";
  $message .= "Sede: " . $sede . "\n";
  $message .= "Nombre: " . $nombre . "\n";
  $message .= "Apellidos: " . $apellidos . "\n";
  $message .= "Teléfono: " . $telefono . "\n";
  $message .= "Correo Electrónico: " . $correo . "\n";

  $headers = 'From: gbarboza.es@gmail.com' . "\r\n";  //dirección de correo a quien le llega
  if (mail($to, $subject, $message, $headers)) {
    // El correo se envió 
    echo "¡Causa el fomulario se envio correctamente!";
  } else {
    // error al enviar el correo
    echo "Causa no quiero alarmarte pero, el formulario no se envio πππππππ";
  }
}
?>
