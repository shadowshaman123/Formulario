function validarnombre() {
  var c = window.event.keyCode;
  if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122)) {
  } else {
    alert("Ponga bien el nombre por favor causa");
    window.event.keyCode = 0;
  }
}

function validarapellido() {
  var c = window.event.keyCode;
  if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122)) {
  } else {
    alert("Ponga bien el apellido por favor causa");
    window.event.keyCode = 0;
  }
}

function validarnumero() {
  var c = window.event.keyCode;
  if (c >= 48 && c <= 57) {
  } else {
    alert("Y por que a los de sistemas nos gritan despues, Causa pon bien el numero de telefono");
    window.event.keyCode = 0;
  }
}

function validarcorreo() {
  var c = window.event.keyCode;
  var co = window.event.keyCode;
  if (
    (c >= 97 && c <= 122) ||
    (co >= 46 && co <= 46) ||
    (c >= 48 && c <= 57) ||
    (c >= 64 && c <= 64) ||
    (c >= alt + 64 && c <= alt + 64)
  ) {
  } else {
    alert("Ponga un correo que sea válido");
    window.event.keyCode = 0;
  }
}

function validartodo() {
  var cad = "";
  if (document.form1.nombre.value == "") {
    cad += "\nIngrese su nombre";
  }
  if (document.form1.apellido.value == "") {
    cad += "\nIngrese su apellido";
  }
  if (document.form1.correo.value == "") {
    cad += "\nIngrese su correo";
  }
  if (document.form1.celular.value == "") {
    cad += "\nIngrese su telefono";
  }
  if (cad != "") {
    alert(cad);
  }
}
